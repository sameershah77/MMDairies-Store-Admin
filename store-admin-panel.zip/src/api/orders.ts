import { apiRequest } from '@/lib/apiClient';
import type {
  CancelOrderRequest,
  OrderBillDto,
  OrderDetailsDto,
  OrderListItemDto,
  PagedResultDto,
  StoreOrdersQuery,
  TransferOrderRequest,
  UpdateOrderStatusRequest,
} from '@/types/api';

export function getAllOrdersByStoreId(query: StoreOrdersQuery) {
  const params = new URLSearchParams();
  if (query.storeId?.trim()) params.set('storeId', query.storeId.trim());
  params.set('statuses', query.statuses);
  if (query.from) params.set('from', query.from);
  if (query.to) params.set('to', query.to);
  params.set('page', String(query.page ?? 1));
  params.set('pageSize', String(query.pageSize ?? 20));

  return apiRequest<PagedResultDto<OrderListItemDto>>(
    `/api/v1/Order/GetAllOrdersByStoreId?${params.toString()}`,
  );
}

export function getOrderByOrderId(orderId: string) {
  return apiRequest<OrderDetailsDto>(`/api/v1/Order/GetOrderByOrderId/${orderId}`);
}

export function getOrderBill(orderId: string) {
  const params = new URLSearchParams({
    orderId,
    is_customer: 'false',
  });
  return apiRequest<OrderBillDto>(`/api/v1/Order/GetBill?${params.toString()}`);
}

export function updateOrderStatus(body: UpdateOrderStatusRequest) {
  return apiRequest<OrderDetailsDto>('/api/v1/Order/UpdateOrderStatus', {
    method: 'PUT',
    body,
  });
}

export function cancelOrder(body: CancelOrderRequest) {
  return apiRequest<OrderDetailsDto>('/api/v1/Order/CancelOrder', {
    method: 'POST',
    body,
  });
}

export function transferOrder(body: TransferOrderRequest) {
  return apiRequest<OrderDetailsDto>('/api/v1/Order/TransferOrder', {
    method: 'POST',
    body,
  });
}
