import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react';
import { initialOrders, nowTimeLabel, TODAY } from '@/data/mockData';
import type { DeliveryEta, Order } from '@/types';

interface OrdersContextValue {
  orders: Order[];
  liveOrders: Order[];
  runningOrders: Order[];
  completedOrders: Order[];
  acceptOrder: (id: string, eta: DeliveryEta) => void;
  rejectOrder: (id: string) => void;
  markDelivered: (id: string) => void;
  getOrder: (id: string) => Order | undefined;
}

const OrdersContext = createContext<OrdersContextValue | null>(null);

const RUNNING: Order['status'][] = ['accepted', 'preparing', 'out_for_delivery'];

export function OrdersProvider({ children }: { children: ReactNode }) {
  const [orders, setOrders] = useState<Order[]>(initialOrders);

  const liveOrders = useMemo(
    () => orders.filter((o) => o.date === TODAY && o.status === 'pending'),
    [orders],
  );

  const runningOrders = useMemo(
    () => orders.filter((o) => o.date === TODAY && RUNNING.includes(o.status)),
    [orders],
  );

  const completedOrders = useMemo(
    () => orders.filter((o) => o.status === 'delivered'),
    [orders],
  );

  const acceptOrder = useCallback((id: string, eta: DeliveryEta) => {
    setOrders((prev) =>
      prev.map((o) =>
        o.id === id
          ? {
              ...o,
              status: 'preparing',
              acceptedTime: nowTimeLabel(),
              expectedDelivery: eta,
              deliveryStatus: 'Preparing',
            }
          : o,
      ),
    );
  }, []);

  const rejectOrder = useCallback((id: string) => {
    setOrders((prev) =>
      prev.map((o) =>
        o.id === id
          ? { ...o, status: 'cancelled', deliveryStatus: 'Not Available' }
          : o,
      ),
    );
  }, []);

  const markDelivered = useCallback((id: string) => {
    setOrders((prev) =>
      prev.map((o) =>
        o.id === id
          ? {
              ...o,
              status: 'delivered',
              deliveredTime: nowTimeLabel(),
              deliveryStatus: 'Delivered',
            }
          : o,
      ),
    );
  }, []);

  const getOrder = useCallback((id: string) => orders.find((o) => o.id === id), [orders]);

  const value = useMemo(
    () => ({
      orders,
      liveOrders,
      runningOrders,
      completedOrders,
      acceptOrder,
      rejectOrder,
      markDelivered,
      getOrder,
    }),
    [orders, liveOrders, runningOrders, completedOrders, acceptOrder, rejectOrder, markDelivered, getOrder],
  );

  return <OrdersContext.Provider value={value}>{children}</OrdersContext.Provider>;
}

export function useOrders() {
  const ctx = useContext(OrdersContext);
  if (!ctx) throw new Error('useOrders must be used within OrdersProvider');
  return ctx;
}
