const CLOUD_NAME =
  (import.meta.env.VITE_CLOUDINARY_CLOUD_NAME as string | undefined)?.trim() || 'nppk3dtf';
const UPLOAD_PRESET =
  (import.meta.env.VITE_CLOUDINARY_UPLOAD_PRESET as string | undefined)?.trim() || 'mm_dairy';

const IMAGE_EXT = /\.(png|jpe?g|webp|gif|bmp|svg|heic|heif)$/i;
const VIDEO_EXT = /\.(mp4|mov|webm|m4v|avi|mkv)$/i;
const UPLOAD_TIMEOUT_MS = 90000;
const MAX_IMAGE_BYTES = 10 * 1024 * 1024;
const MAX_VIDEO_BYTES = 40 * 1024 * 1024;

export type CloudinaryMediaType = 'image' | 'video';

function detectMediaType(file: File): CloudinaryMediaType | null {
  if (file.type.startsWith('image/') || IMAGE_EXT.test(file.name)) return 'image';
  if (file.type.startsWith('video/') || VIDEO_EXT.test(file.name)) return 'video';
  return null;
}

export async function uploadMediaToCloudinary(
  file: File,
  folder = 'mm-dairies/complaints',
): Promise<{ url: string; mediaType: CloudinaryMediaType }> {
  const mediaType = detectMediaType(file);
  if (!mediaType) {
    throw new Error('Please select an image or video file.');
  }
  if (mediaType === 'image' && file.size > MAX_IMAGE_BYTES) {
    throw new Error('Image must be under 10MB.');
  }
  if (mediaType === 'video' && file.size > MAX_VIDEO_BYTES) {
    throw new Error('Video must be under 40MB.');
  }

  const form = new FormData();
  form.append('file', file);
  form.append('upload_preset', UPLOAD_PRESET);
  if (folder) form.append('folder', folder);

  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), UPLOAD_TIMEOUT_MS);
  const resource = mediaType === 'video' ? 'video' : 'image';

  let res: Response;
  try {
    res = await fetch(`https://api.cloudinary.com/v1_1/${CLOUD_NAME}/${resource}/upload`, {
      method: 'POST',
      body: form,
      signal: controller.signal,
    });
  } catch (err) {
    if (err instanceof DOMException && err.name === 'AbortError') {
      throw new Error('Cloudinary upload timed out. Check your network and try again.');
    }
    throw new Error('Unable to reach Cloudinary. Check your network connection.');
  } finally {
    window.clearTimeout(timer);
  }

  const data = (await res.json().catch(() => ({}))) as {
    secure_url?: string;
    url?: string;
    error?: { message?: string } | string;
  };

  if (!res.ok) {
    const msg =
      typeof data.error === 'string'
        ? data.error
        : data.error?.message || `Cloudinary upload failed (${res.status}).`;
    throw new Error(msg);
  }

  const url = data.secure_url || data.url;
  if (!url) {
    throw new Error('Cloudinary did not return a media URL.');
  }
  return { url, mediaType };
}
