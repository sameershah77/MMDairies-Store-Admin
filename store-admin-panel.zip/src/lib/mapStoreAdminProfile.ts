import type { AuthAdminDto, StoreAdminMyProfileDto, StoreListItemDto } from '@/types/api';
import type { AssignedStoreRef, StoreAdminProfile } from '@/types';

type ProfileSource = {
  user_id: string;
  first_name: string;
  last_name: string | null;
  phone_no: string;
  username: string;
  assigned_store?: string | null;
  assigned_stores?: string[];
};

function storeIdsFrom(source: ProfileSource): string[] {
  const fromList = (source.assigned_stores ?? []).filter(Boolean);
  if (fromList.length) return fromList;
  return source.assigned_store ? [source.assigned_store] : [];
}

export function mapStoreAdminProfile(
  source: ProfileSource,
  stores: StoreListItemDto[] = [],
): StoreAdminProfile {
  const firstName = source.first_name?.trim() || '';
  const lastName = source.last_name?.trim() || '';
  const username = source.username || '';
  const name = [firstName, lastName].filter(Boolean).join(' ') || username || 'Store Admin';
  const ids = storeIdsFrom(source);
  const assignedStores: AssignedStoreRef[] = ids.map((id) => ({
    id,
    name: stores.find((s) => s.store_id === id)?.store_name || id,
  }));
  const primary = assignedStores[0];

  return {
    name,
    firstName,
    lastName,
    username,
    phone: source.phone_no || '',
    email: username ? `${username}@mmdairies.com` : '',
    avatar: `https://api.dicebear.com/9.x/avataaars/svg?seed=${encodeURIComponent(username || name)}`,
    dairyName: 'MM Dairies',
    zoneName: primary?.name || (ids.length ? 'Assigned store' : 'Unassigned'),
    storeName: assignedStores.map((s) => s.name).join(', ') || (ids.length ? 'Assigned store' : 'No store assigned'),
    storeId: ids[0] || '',
    userId: source.user_id,
    assignedStores,
  };
}

export function mapAuthAdminToProfile(admin: AuthAdminDto, stores: StoreListItemDto[] = []) {
  return mapStoreAdminProfile(admin, stores);
}

export function mapMyProfileDto(dto: StoreAdminMyProfileDto, stores: StoreListItemDto[] = []) {
  return mapStoreAdminProfile(dto, stores);
}

export function otpFromData(data: unknown): string {
  if (!data || typeof data !== 'object') return '';
  const rec = data as Record<string, unknown>;
  if (typeof rec.otp === 'string' && rec.otp.trim()) return rec.otp.trim();
  if (rec.data && typeof rec.data === 'object') {
    const inner = rec.data as Record<string, unknown>;
    if (typeof inner.otp === 'string' && inner.otp.trim()) return inner.otp.trim();
  }
  return '';
}
