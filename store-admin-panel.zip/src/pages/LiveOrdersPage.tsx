import { RefreshCw } from 'lucide-react';
import { PageHeader } from '@/components/ui/PageHeader';
import { Button } from '@/components/ui/Button';
import { EmptyState } from '@/components/ui/EmptyState';
import { Pagination } from '@/components/ui/Pagination';
import { TableSkeleton } from '@/components/ui/Skeleton';
import { OrderBoardTable } from '@/components/orders/OrderBoardTable';
import { usePagedStoreOrders } from '@/hooks/usePagedStoreOrders';
import { BOARD_STATUSES } from '@/lib/orderStatus';

export function LiveOrdersPage() {
  const {
    items,
    page,
    setPage,
    totalCount,
    totalPages,
    loading,
    error,
    refresh,
    isConnected,
  } = usePagedStoreOrders({
    board: 'live',
    statuses: BOARD_STATUSES.live,
  });

  return (
    <div>
      <PageHeader
        title="Live Orders"
        subtitle="Placed orders waiting for accept"
        actions={
          <Button
            variant="outline"
            icon={<RefreshCw className={`size-4 ${loading ? 'animate-spin' : ''}`} />}
            onClick={() => void refresh()}
            disabled={loading}
          >
            Refresh
          </Button>
        }
      />

      <div className="mb-4 flex flex-wrap items-center gap-2">
        <span className="live-dot size-2.5 rounded-full bg-green-500" />
        <p className="text-sm font-semibold text-ink-800">Incoming Queue</p>
        <span className="text-sm text-ink-500">
          {loading ? '…' : `${totalCount} live`}
        </span>
        <span className="text-xs text-ink-400">
          · Realtime {isConnected ? 'on' : 'off'}
        </span>
      </div>

      {loading ? (
        <TableSkeleton rows={6} />
      ) : error ? (
        <EmptyState
          title="Could not load orders"
          description={error}
          actionLabel="Try again"
          onAction={() => void refresh()}
        />
      ) : items.length === 0 ? (
        <EmptyState
          title="No live orders"
          description="Placed orders waiting for your action will appear here."
        />
      ) : (
        <>
          <OrderBoardTable orders={items} />
          <Pagination
            page={page}
            totalPages={totalPages}
            onChange={setPage}
            totalItems={totalCount}
          />
        </>
      )}
    </div>
  );
}
