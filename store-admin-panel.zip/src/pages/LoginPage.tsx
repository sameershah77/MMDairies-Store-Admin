import { useState, type FormEvent } from 'react';
import { Navigate, useLocation, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Eye, EyeOff, Lock, Moon, Sun, User } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useTheme } from '@/context/ThemeContext';
import { useToast } from '@/context/ToastContext';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { resetPassword, sendForgotPasswordOtp } from '@/api/auth';
import { ApiError } from '@/lib/apiClient';
import { otpFromData } from '@/lib/mapStoreAdminProfile';

type LoginMode = 'signin' | 'forgot-phone' | 'forgot-reset';

export function LoginPage() {
  const { isAuthenticated, login } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const { toast } = useToast();
  const navigate = useNavigate();
  const location = useLocation();
  const loginHint = (location.state as { login?: string } | null)?.login ?? '';

  const [mode, setMode] = useState<LoginMode>('signin');
  const [username, setUsername] = useState(loginHint);
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const [forgotPhone, setForgotPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showNewPass, setShowNewPass] = useState(false);

  if (isAuthenticated) return <Navigate to="/" replace />;

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    const res = await login(username, password);
    setLoading(false);
    if (!res.ok) {
      setError(res.error || 'Login failed');
      toast(res.error || 'Login failed', 'error');
      return;
    }
    toast('Welcome back to MM Dairies');
    navigate('/');
  };

  const handleSendForgotOtp = async (e: FormEvent) => {
    e.preventDefault();
    const phoneNo = forgotPhone.replace(/\D/g, '');
    if (phoneNo.length !== 10) {
      setError('Enter a valid 10-digit phone number');
      return;
    }
    setError('');
    setLoading(true);
    try {
      const data = await sendForgotPasswordOtp(phoneNo);
      setOtp(otpFromData(data));
      setMode('forgot-reset');
      toast('If this phone is registered, an OTP has been sent.', 'info');
    } catch (err) {
      const message = err instanceof ApiError ? err.message : 'Could not send OTP';
      setError(message);
      toast(message, 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleResetPassword = async (e: FormEvent) => {
    e.preventDefault();
    const phoneNo = forgotPhone.replace(/\D/g, '');
    if (!otp.trim()) {
      setError('OTP is required');
      return;
    }
    if (newPassword.length < 8) {
      setError('Password must be at least 8 characters.');
      return;
    }
    if (newPassword !== confirmPassword) {
      setError('New password and confirm password do not match.');
      return;
    }
    setError('');
    setLoading(true);
    try {
      const message = await resetPassword({
        phoneNo,
        otp: otp.trim(),
        newPassword,
        confirmPassword,
      });
      toast(message || 'Password reset successfully. Please sign in.');
      setMode('signin');
      setUsername(phoneNo);
      setPassword('');
      setOtp('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (err) {
      const message = err instanceof ApiError ? err.message : 'Could not reset password';
      setError(message);
      toast(message, 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="relative hidden overflow-hidden bg-brand-700 lg:flex lg:flex-col lg:justify-between">
        <div
          className="absolute inset-0 opacity-40"
          style={{
            backgroundImage:
              'radial-gradient(circle at 20% 30%, #3fa896 0%, transparent 45%), radial-gradient(circle at 80% 70%, #0a5c5f 0%, transparent 40%)',
          }}
        />
        <div
          className="absolute inset-0 opacity-[0.07]"
          style={{
            backgroundImage:
              'url("data:image/svg+xml,%3Csvg width=\'60\' height=\'60\' viewBox=\'0 0 60 60\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cg fill=\'none\' fill-rule=\'evenodd\'%3E%3Cg fill=\'%23ffffff\' fill-opacity=\'1\'%3E%3Cpath d=\'M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z\'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")',
          }}
        />

        <div className="relative z-10 p-10">
          <div className="flex items-center gap-3">
            <div className="flex size-11 items-center justify-center rounded-xl bg-white/15 text-white backdrop-blur">
              <svg viewBox="0 0 24 24" className="size-6" fill="none">
                <path
                  d="M6 15c0-3.5 2.8-7 6-7s6 3.5 6 7"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                />
                <circle cx="12" cy="8" r="2.5" fill="currentColor" />
              </svg>
            </div>
            <div>
              <p className="font-display text-xl font-bold text-white">MM Dairies</p>
              <p className="text-xs font-medium tracking-widest text-brand-200 uppercase">
                Fresh · Daily · Trusted
              </p>
            </div>
          </div>
        </div>

        <div className="relative z-10 flex flex-1 flex-col items-center justify-center px-12 pb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="w-full max-w-md"
          >
            <div className="relative mx-auto mb-10 aspect-square max-w-xs">
              <motion.div
                animate={{ y: [0, -12, 0] }}
                transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
                className="absolute inset-0 rounded-[2rem] bg-gradient-to-br from-white/20 to-white/5 shadow-2xl backdrop-blur-sm"
              />
              <motion.img
                animate={{ y: [0, -8, 0] }}
                transition={{ duration: 3.5, repeat: Infinity, ease: 'easeInOut', delay: 0.2 }}
                src="https://images.unsplash.com/photo-1550583724-b2692b85b150?w=600&h=600&fit=crop"
                alt="Fresh dairy"
                className="absolute inset-4 rounded-[1.5rem] object-cover shadow-xl"
              />
              <motion.div
                animate={{ y: [0, 8, 0] }}
                transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut', delay: 0.4 }}
                className="absolute -right-4 bottom-10 rounded-2xl bg-surface px-4 py-3 shadow-xl"
              >
                <p className="text-xs font-medium text-ink-400">Today's Orders</p>
                <p className="font-display text-xl font-bold text-brand-600">42</p>
              </motion.div>
              <motion.div
                animate={{ y: [0, -6, 0] }}
                transition={{ duration: 3.2, repeat: Infinity, ease: 'easeInOut', delay: 0.6 }}
                className="absolute -left-4 top-16 rounded-2xl bg-surface px-4 py-3 shadow-xl"
              >
                <p className="text-xs font-medium text-ink-400">Live Queue</p>
                <p className="font-display text-xl font-bold text-ink-800">4</p>
              </motion.div>
            </div>
            <h2 className="font-display text-3xl font-bold text-white">
              Run your store with confidence
            </h2>
            <p className="mt-3 text-base leading-relaxed text-brand-100">
              Accept live orders, manage products for your zone, and keep customers happy — all from
              one store dashboard built for MM Dairies.
            </p>
          </motion.div>
        </div>

        <div className="relative z-10 p-10 text-sm text-brand-200">
          © {new Date().getFullYear()} MM Dairies. All rights reserved.
        </div>
      </div>

      <div className="relative flex items-center justify-center bg-ink-50 px-5 py-12 sm:px-8">
        <button
          type="button"
          onClick={toggleTheme}
          className="absolute top-5 right-5 z-10 rounded-xl border border-ink-200 bg-surface p-2.5 text-ink-600 shadow-sm transition hover:border-brand-300 hover:text-brand-500"
          title={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
          aria-label="Toggle theme"
        >
          {theme === 'dark' ? <Sun className="size-5" /> : <Moon className="size-5" />}
        </button>
        <div
          className="pointer-events-none absolute inset-0 opacity-60"
          style={{
            background:
              'radial-gradient(ellipse at top right, rgba(13,115,119,0.08), transparent 50%), radial-gradient(ellipse at bottom left, rgba(232,168,56,0.06), transparent 45%)',
          }}
        />

        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="relative w-full max-w-[420px]"
        >
          <div className="mb-8 flex items-center gap-3 lg:hidden">
            <div className="flex size-10 items-center justify-center rounded-xl bg-brand-500 text-white">
              <svg viewBox="0 0 24 24" className="size-5" fill="none">
                <path
                  d="M6 15c0-3.5 2.8-7 6-7s6 3.5 6 7"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                />
                <circle cx="12" cy="8" r="2.5" fill="currentColor" />
              </svg>
            </div>
            <div>
              <p className="font-display text-lg font-bold text-ink-900">MM Dairies</p>
              <p className="text-xs text-brand-500">Store Admin</p>
            </div>
          </div>

          <div className="rounded-3xl border border-ink-100 bg-surface p-7 shadow-xl shadow-ink-900/5 sm:p-9">
            {mode === 'signin' ? (
              <>
                <h1 className="font-display text-2xl font-bold text-ink-900 sm:text-3xl">
                  Welcome back
                </h1>
                <p className="mt-2 text-sm text-ink-500">
                  Sign in with your phone number or username.
                </p>

                <form onSubmit={handleSubmit} className="mt-8 space-y-5">
                  <Input
                    label="Phone or username"
                    type="text"
                    placeholder="9876543210 or Irfan123"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    leftIcon={<User className="size-4" />}
                    autoComplete="username"
                    required
                  />
                  <Input
                    label="Password"
                    type={showPass ? 'text' : 'password'}
                    placeholder="Enter your password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    leftIcon={<Lock className="size-4" />}
                    rightIcon={
                      <button
                        type="button"
                        onClick={() => setShowPass((v) => !v)}
                        className="text-ink-400 hover:text-ink-600"
                        tabIndex={-1}
                      >
                        {showPass ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                      </button>
                    }
                    autoComplete="current-password"
                    required
                  />

                  <div className="flex justify-end">
                    <button
                      type="button"
                      className="text-sm font-semibold text-brand-600 hover:text-brand-700"
                      onClick={() => {
                        setError('');
                        const digits = username.replace(/\D/g, '');
                        setForgotPhone(digits.length === 10 ? digits : '');
                        setMode('forgot-phone');
                      }}
                    >
                      Forgot password?
                    </button>
                  </div>

                  {error && (
                    <p className="rounded-xl bg-red-50 px-3 py-2 text-sm font-medium text-danger dark:bg-red-500/15">
                      {error}
                    </p>
                  )}

                  <Button type="submit" size="lg" className="w-full" loading={loading}>
                    Login
                  </Button>
                </form>
              </>
            ) : mode === 'forgot-phone' ? (
              <>
                <h1 className="font-display text-2xl font-bold text-ink-900 sm:text-3xl">
                  Forgot password
                </h1>
                <p className="mt-2 text-sm text-ink-500">
                  Enter the phone number registered with your Store Admin account.
                </p>
                <form onSubmit={handleSendForgotOtp} className="mt-8 space-y-5">
                  <Input
                    label="Phone number"
                    type="tel"
                    placeholder="9876543210"
                    value={forgotPhone}
                    onChange={(e) => setForgotPhone(e.target.value)}
                    required
                  />
                  {error && (
                    <p className="rounded-xl bg-red-50 px-3 py-2 text-sm font-medium text-danger dark:bg-red-500/15">
                      {error}
                    </p>
                  )}
                  <Button type="submit" size="lg" className="w-full" loading={loading}>
                    Send OTP
                  </Button>
                  <button
                    type="button"
                    className="w-full text-center text-sm font-semibold text-ink-500 hover:text-ink-800"
                    onClick={() => {
                      setError('');
                      setMode('signin');
                    }}
                  >
                    Back to sign in
                  </button>
                </form>
              </>
            ) : (
              <>
                <h1 className="font-display text-2xl font-bold text-ink-900 sm:text-3xl">
                  Reset password
                </h1>
                <p className="mt-2 text-sm text-ink-500">
                  Enter the OTP sent to {forgotPhone.replace(/\D/g, '')} and choose a new password.
                </p>
                <form onSubmit={handleResetPassword} className="mt-8 space-y-5">
                  <Input
                    label="OTP"
                    value={otp}
                    onChange={(e) => setOtp(e.target.value)}
                    placeholder="Enter 6-digit OTP"
                    hint="Development: OTP is filled from the API when available."
                    required
                  />
                  <Input
                    label="New password"
                    type={showNewPass ? 'text' : 'password'}
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    leftIcon={<Lock className="size-4" />}
                    rightIcon={
                      <button
                        type="button"
                        onClick={() => setShowNewPass((v) => !v)}
                        className="text-ink-400 hover:text-ink-600"
                        tabIndex={-1}
                      >
                        {showNewPass ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                      </button>
                    }
                    required
                  />
                  <Input
                    label="Confirm password"
                    type={showNewPass ? 'text' : 'password'}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    required
                  />
                  {error && (
                    <p className="rounded-xl bg-red-50 px-3 py-2 text-sm font-medium text-danger dark:bg-red-500/15">
                      {error}
                    </p>
                  )}
                  <Button type="submit" size="lg" className="w-full" loading={loading}>
                    Reset password
                  </Button>
                  <button
                    type="button"
                    className="w-full text-center text-sm font-semibold text-ink-500 hover:text-ink-800"
                    onClick={() => {
                      setError('');
                      setMode('forgot-phone');
                    }}
                  >
                    Use a different phone
                  </button>
                </form>
              </>
            )}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
