import { useMemo, useState, useRef, useEffect } from 'react';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { ArrowLeft, MessageCircle, Send } from 'lucide-react';
import { PageHeader } from '@/components/ui/PageHeader';
import { Button } from '@/components/ui/Button';
import { SearchInput } from '@/components/ui/SearchInput';
import { EmptyState } from '@/components/ui/EmptyState';
import { Pagination } from '@/components/ui/Pagination';
import { Modal } from '@/components/ui/Modal';
import { customers, chatThreads, formatCurrency, formatDate, nowTimeLabel } from '@/data/mockData';
import type { ChatMessage } from '@/types';
import { useToast } from '@/context/ToastContext';

const PAGE_SIZE = 8;

export function CustomersPage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const initialQ = searchParams.get('q') || '';
  const [search, setSearch] = useState(initialQ);
  const [page, setPage] = useState(1);

  const filtered = useMemo(
    () =>
      customers.filter(
        (c) =>
          c.name.toLowerCase().includes(search.toLowerCase()) ||
          c.phone.includes(search) ||
          c.email.toLowerCase().includes(search.toLowerCase()),
      ),
    [search],
  );

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const items = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  return (
    <div>
      <PageHeader
        title="Customers"
        subtitle="Customers who have ordered from your store"
      />

      <div className="mb-5">
        <SearchInput
          placeholder="Search Customer"
          value={search}
          onChange={(e) => {
            setSearch(e.target.value);
            setPage(1);
          }}
          containerClassName="max-w-md"
        />
      </div>

      {items.length === 0 ? (
        <EmptyState title="No customers found" description="Try a different search term." />
      ) : (
        <div className="overflow-hidden rounded-2xl border border-ink-100 bg-surface shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[480px] text-left text-sm">
              <thead>
                <tr className="border-b border-ink-100 bg-ink-50/80 text-xs font-semibold tracking-wide text-ink-400 uppercase">
                  <th className="px-5 py-3.5">Customer Name</th>
                  <th className="px-5 py-3.5">Profile</th>
                  <th className="px-5 py-3.5">Total Orders</th>
                </tr>
              </thead>
              <tbody>
                {items.map((c) => (
                  <tr
                    key={c.id}
                    className="cursor-pointer border-b border-ink-50 transition last:border-0 hover:bg-brand-50/40"
                    onClick={() => navigate(`/customers/${c.id}`)}
                  >
                    <td className="px-5 py-4">
                      <p className="font-semibold text-ink-900">{c.name}</p>
                      <p className="text-xs text-ink-400">{c.phone}</p>
                    </td>
                    <td className="px-5 py-4">
                      <img src={c.avatar} alt="" className="size-10 rounded-xl bg-ink-100" />
                    </td>
                    <td className="px-5 py-4 font-semibold text-ink-800">{c.totalOrders}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="px-5 pb-4">
            <Pagination
              page={page}
              totalPages={totalPages}
              onChange={setPage}
              totalItems={filtered.length}
            />
          </div>
        </div>
      )}
    </div>
  );
}

export function CustomerDetailPage() {
  const { customerId } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const customer = customers.find((c) => c.id === customerId);

  const [chatOpen, setChatOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>(
    () => (customerId ? chatThreads[customerId] || [] : []).slice(),
  );
  const [draft, setDraft] = useState('');
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (chatOpen) {
      bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [chatOpen, messages]);

  if (!customer) {
    return (
      <EmptyState
        title="Customer not found"
        actionLabel="Back to Customers"
        onAction={() => navigate('/customers')}
      />
    );
  }

  const sendMessage = () => {
    if (!draft.trim()) return;
    const msg: ChatMessage = {
      id: `m${Date.now()}`,
      sender: 'admin',
      text: draft.trim(),
      time: nowTimeLabel(),
    };
    setMessages((prev) => [...prev, msg]);
    setDraft('');
    toast('Message sent');
  };

  return (
    <div>
      <PageHeader
        title="Customer Profile"
        subtitle="Store customer details"
        actions={
          <Button
            variant="outline"
            icon={<ArrowLeft className="size-4" />}
            onClick={() => navigate('/customers')}
          >
            Back
          </Button>
        }
      />

      <div className="mx-auto max-w-2xl overflow-hidden rounded-3xl border border-ink-100 bg-surface shadow-sm">
        <div className="h-28 bg-gradient-to-r from-brand-600 to-brand-400" />
        <div className="relative px-6 pb-8 sm:px-8">
          <img
            src={customer.avatar}
            alt={customer.name}
            className="-mt-12 size-24 rounded-2xl border-4 border-white bg-ink-100 shadow-md"
          />
          <h2 className="mt-4 font-display text-2xl font-bold text-ink-900">{customer.name}</h2>
          <p className="mt-1 text-sm text-ink-500">{customer.email}</p>
          <p className="text-sm text-ink-500">{customer.phone}</p>

          <dl className="mt-6 grid gap-3 sm:grid-cols-2">
            <div className="rounded-xl bg-ink-50 px-4 py-3 sm:col-span-2">
              <dt className="text-xs font-medium tracking-wide text-ink-400 uppercase">Address</dt>
              <dd className="mt-1 text-sm font-semibold text-ink-800">{customer.address}</dd>
            </div>
            <div className="rounded-xl bg-ink-50 px-4 py-3">
              <dt className="text-xs font-medium tracking-wide text-ink-400 uppercase">
                Customer Since
              </dt>
              <dd className="mt-1 text-sm font-semibold text-ink-800">
                {formatDate(customer.customerSince)}
              </dd>
            </div>
            <div className="rounded-xl bg-brand-50 px-4 py-3">
              <dt className="text-xs font-medium tracking-wide text-brand-500 uppercase">
                Total Orders
              </dt>
              <dd className="mt-1 font-display text-xl font-bold text-brand-700">
                {customer.totalOrders}
              </dd>
            </div>
            <div className="rounded-xl bg-amber-50 px-4 py-3 dark:bg-amber-500/15 sm:col-span-2">
              <dt className="text-xs font-medium tracking-wide text-amber-600 uppercase dark:text-amber-300">
                Total Revenue
              </dt>
              <dd className="mt-1 font-display text-xl font-bold text-amber-700 dark:text-amber-300">
                {formatCurrency(customer.totalRevenue)}
              </dd>
            </div>
          </dl>

          <Button
            className="mt-6 w-full sm:w-auto"
            icon={<MessageCircle className="size-4" />}
            onClick={() => setChatOpen(true)}
          >
            Resolve Query
          </Button>
        </div>
      </div>

      <Modal
        open={chatOpen}
        onClose={() => setChatOpen(false)}
        title={`Chat · ${customer.name}`}
        description="In-app support conversation"
        size="md"
      >
        <div className="flex h-[420px] flex-col">
          <div className="flex-1 space-y-3 overflow-y-auto rounded-xl bg-ink-50 p-3">
            {messages.length === 0 ? (
              <p className="py-10 text-center text-sm text-ink-400">
                No previous messages. Start the conversation.
              </p>
            ) : (
              messages.map((m) => (
                <div
                  key={m.id}
                  className={`flex ${m.sender === 'admin' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[80%] rounded-2xl px-3.5 py-2.5 text-sm ${
                      m.sender === 'admin'
                        ? 'rounded-br-md bg-brand-500 text-white'
                        : 'rounded-bl-md border border-ink-100 bg-surface text-ink-800'
                    }`}
                  >
                    <p>{m.text}</p>
                    <p
                      className={`mt-1 text-[10px] ${
                        m.sender === 'admin' ? 'text-brand-100' : 'text-ink-400'
                      }`}
                    >
                      {m.time}
                    </p>
                  </div>
                </div>
              ))
            )}
            <div ref={bottomRef} />
          </div>
          <div className="mt-3 flex gap-2">
            <input
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  sendMessage();
                }
              }}
              placeholder="Type a message..."
              className="h-11 flex-1 rounded-xl border border-ink-200 bg-surface px-3.5 text-sm outline-none focus:border-brand-400 focus:ring-3 focus:ring-brand-500/15"
            />
            <Button icon={<Send className="size-4" />} onClick={sendMessage}>
              Send
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
