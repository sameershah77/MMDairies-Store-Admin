import { useMemo, useState } from 'react';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { IndianRupee, Package, ShoppingBag, TrendingUp } from 'lucide-react';
import { PageHeader, StatCard } from '@/components/ui/PageHeader';
import { useChartTheme } from '@/hooks/useChartTheme';
import { useOrders } from '@/context/OrdersContext';
import {
  categoryRevenueChart,
  formatCurrency,
  formatNumber,
  hourlyOrdersChart,
  TODAY,
  topProductsChart,
} from '@/data/mockData';

export function ReportsPage() {
  const [from, setFrom] = useState(TODAY);
  const [to, setTo] = useState(TODAY);
  const chart = useChartTheme();
  const { orders, completedOrders } = useOrders();

  const inRange = useMemo(
    () =>
      orders.filter(
        (o) =>
          o.status !== 'cancelled' &&
          (!from || o.date >= from) &&
          (!to || o.date <= to),
      ),
    [orders, from, to],
  );

  const revenue = inRange.reduce((s, o) => s + o.totalAmount, 0);
  const orderCount = inRange.length;
  const aov = orderCount ? Math.round(revenue / orderCount) : 0;
  const productsSold = inRange.reduce((s, o) => s + o.quantity, 0);

  const isToday = from === TODAY && to === TODAY;

  return (
    <div>
      <PageHeader
        title="Reports"
        subtitle={isToday ? "Today's store performance report" : 'Store performance for selected range'}
        actions={
          <div className="flex flex-wrap items-end gap-2">
            <div>
              <label className="mb-1 block text-xs font-semibold text-ink-500">From</label>
              <input
                type="date"
                value={from}
                onChange={(e) => setFrom(e.target.value)}
                className="h-10 rounded-xl border border-ink-200 bg-surface px-3 text-sm text-ink-800 outline-none focus:border-brand-400 [color-scheme:light] dark:[color-scheme:dark]"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-ink-500">To</label>
              <input
                type="date"
                value={to}
                onChange={(e) => setTo(e.target.value)}
                className="h-10 rounded-xl border border-ink-200 bg-surface px-3 text-sm text-ink-800 outline-none focus:border-brand-400 [color-scheme:light] dark:[color-scheme:dark]"
              />
            </div>
            <button
              type="button"
              onClick={() => {
                setFrom(TODAY);
                setTo(TODAY);
              }}
              className="h-10 rounded-xl border border-ink-200 px-3 text-sm font-semibold text-ink-600 hover:bg-ink-50"
            >
              Today
            </button>
          </div>
        }
      />

      <p className="mb-4 text-sm text-ink-500">
        Showing reports for <span className="font-semibold text-ink-700">{from}</span> to{' '}
        <span className="font-semibold text-ink-700">{to}</span>
        {' · '}
        {completedOrders.filter((o) => o.date === TODAY).length} delivered today
      </p>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label="Today's Revenue"
          value={formatCurrency(isToday ? revenue || 18450 : revenue)}
          icon={<IndianRupee className="size-5" />}
          tone="brand"
        />
        <StatCard
          label="Today's Orders"
          value={formatNumber(isToday ? orderCount || 42 : orderCount)}
          icon={<ShoppingBag className="size-5" />}
          tone="accent"
        />
        <StatCard
          label="Average Order Value"
          value={formatCurrency(aov || 439)}
          icon={<TrendingUp className="size-5" />}
          tone="success"
        />
        <StatCard
          label="Total Products Sold"
          value={formatNumber(productsSold || 58)}
          icon={<Package className="size-5" />}
          tone="ink"
        />
      </div>

      <div className="mt-6 grid gap-4 xl:grid-cols-2">
        <div className="rounded-2xl border border-ink-100 bg-surface p-5 shadow-sm">
          <h2 className="mb-1 font-display text-base font-bold text-ink-900">
            Category-wise Revenue
          </h2>
          <p className="mb-4 text-xs text-ink-400">Revenue contribution by product category</p>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={categoryRevenueChart}>
              <CartesianGrid strokeDasharray="3 3" stroke={chart.grid} />
              <XAxis dataKey="label" tick={{ fill: chart.tick, fontSize: 12 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: chart.tick, fontSize: 12 }} axisLine={false} tickLine={false} tickFormatter={(v) => `₹${v / 1000}k`} />
              <Tooltip formatter={(v) => [formatCurrency(Number(v)), 'Revenue']} contentStyle={chart.tooltip} />
              <Bar dataKey="value" fill={chart.brand} radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="rounded-2xl border border-ink-100 bg-surface p-5 shadow-sm">
          <h2 className="mb-1 font-display text-base font-bold text-ink-900">Top Selling Products</h2>
          <p className="mb-4 text-xs text-ink-400">By units sold at this store</p>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={topProductsChart} layout="vertical" margin={{ left: 12 }}>
              <CartesianGrid strokeDasharray="3 3" stroke={chart.grid} horizontal={false} />
              <XAxis type="number" tick={{ fill: chart.tick, fontSize: 12 }} axisLine={false} tickLine={false} />
              <YAxis dataKey="label" type="category" width={90} tick={{ fill: chart.tickMuted, fontSize: 12 }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={chart.tooltip} />
              <Bar dataKey="value" fill={chart.accent} radius={[0, 8, 8, 0]} name="Sold" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="rounded-2xl border border-ink-100 bg-surface p-5 shadow-sm xl:col-span-2">
          <h2 className="mb-1 font-display text-base font-bold text-ink-900">
            Hourly Sales Analysis
          </h2>
          <p className="mb-4 text-xs text-ink-400">Order volume by hour of day</p>
          <ResponsiveContainer width="100%" height={280}>
            <AreaChart data={hourlyOrdersChart}>
              <defs>
                <linearGradient id="hourlyFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={chart.brandSoft} stopOpacity={0.35} />
                  <stop offset="100%" stopColor={chart.brandSoft} stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke={chart.grid} />
              <XAxis dataKey="label" tick={{ fill: chart.tick, fontSize: 12 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: chart.tick, fontSize: 12 }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={chart.tooltip} />
              <Area
                type="monotone"
                dataKey="value"
                stroke={chart.brand}
                strokeWidth={2.5}
                fill="url(#hourlyFill)"
                name="Orders"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
