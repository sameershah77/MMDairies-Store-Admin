import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  IndianRupee,
  ShoppingBag,
  Radio,
  Truck,
  CheckCircle2,
  TrendingUp,
} from 'lucide-react';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { PageHeader, StatCard } from '@/components/ui/PageHeader';
import { StatusBadge } from '@/components/ui/Badge';
import { StatCardSkeleton, TableSkeleton } from '@/components/ui/Skeleton';
import { useChartTheme } from '@/hooks/useChartTheme';
import { useOrders } from '@/context/OrdersContext';
import { useAuth } from '@/context/AuthContext';
import {
  formatCurrency,
  formatNumber,
  hourlyOrdersChart,
  todayRevenueChart,
  topProductsChart,
} from '@/data/mockData';

export function DashboardPage() {
  const [loading, setLoading] = useState(true);
  const chart = useChartTheme();
  const { profile } = useAuth();
  const { liveOrders, runningOrders, completedOrders, orders } = useOrders();

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 700);
    return () => clearTimeout(t);
  }, []);

  const todayCompleted = completedOrders.filter((o) => o.date === '2026-07-13');
  const todayRevenue = orders
    .filter((o) => o.date === '2026-07-13' && o.status !== 'cancelled')
    .reduce((s, o) => s + o.totalAmount, 0);
  const todayOrdersCount =
    liveOrders.length + runningOrders.length + todayCompleted.length;
  const recentOrders = orders
    .filter((o) => o.date === '2026-07-13')
    .slice()
    .sort((a, b) => b.time.localeCompare(a.time))
    .slice(0, 5);

  const stats = [
    {
      label: "Today's Revenue",
      value: formatCurrency(todayRevenue || 18450),
      hint: '+8% vs yesterday',
      icon: <IndianRupee className="size-5" />,
      tone: 'brand' as const,
    },
    {
      label: "Today's Orders",
      value: formatNumber(todayOrdersCount || 42),
      hint: profile.storeName,
      icon: <ShoppingBag className="size-5" />,
      tone: 'accent' as const,
    },
    {
      label: 'Live Orders',
      value: formatNumber(liveOrders.length),
      hint: 'Awaiting action',
      icon: <Radio className="size-5" />,
      tone: 'success' as const,
    },
    {
      label: 'Running Orders',
      value: formatNumber(runningOrders.length),
      hint: 'In progress',
      icon: <Truck className="size-5" />,
      tone: 'ink' as const,
    },
    {
      label: 'Completed Orders',
      value: formatNumber(todayCompleted.length),
      hint: 'Delivered today',
      icon: <CheckCircle2 className="size-5" />,
      tone: 'brand' as const,
    },
  ];

  return (
    <div>
      <PageHeader
        title="Dashboard"
        subtitle={`Today's summary for ${profile.storeName} · ${profile.zoneName}`}
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
        {loading
          ? Array.from({ length: 5 }).map((_, i) => <StatCardSkeleton key={i} />)
          : stats.map((s) => <StatCard key={s.label} {...s} />)}
      </div>

      <div className="mt-6 grid gap-4 xl:grid-cols-2">
        <ChartCard title="Today's Revenue" subtitle="Cumulative through the day">
          <ResponsiveContainer width="100%" height={260}>
            <AreaChart data={todayRevenueChart}>
              <defs>
                <linearGradient id="revFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={chart.brand} stopOpacity={0.3} />
                  <stop offset="100%" stopColor={chart.brand} stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke={chart.grid} />
              <XAxis dataKey="label" tick={{ fill: chart.tick, fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: chart.tick, fontSize: 12 }} axisLine={false} tickLine={false} tickFormatter={(v) => `₹${v / 1000}k`} />
              <Tooltip
                formatter={(v) => [formatCurrency(Number(v)), 'Revenue']}
                contentStyle={chart.tooltip}
              />
              <Area type="monotone" dataKey="value" stroke={chart.brand} strokeWidth={2.5} fill="url(#revFill)" />
            </AreaChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Hourly Orders" subtitle="Orders placed by hour">
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={hourlyOrdersChart}>
              <CartesianGrid strokeDasharray="3 3" stroke={chart.grid} />
              <XAxis dataKey="label" tick={{ fill: chart.tick, fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: chart.tick, fontSize: 12 }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={chart.tooltip} />
              <Bar dataKey="value" fill={chart.brandSoft} radius={[8, 8, 0, 0]} name="Orders" />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Top Selling Products" subtitle="By units sold at this store">
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={topProductsChart} layout="vertical" margin={{ left: 8 }}>
              <CartesianGrid strokeDasharray="3 3" stroke={chart.grid} horizontal={false} />
              <XAxis type="number" tick={{ fill: chart.tick, fontSize: 12 }} axisLine={false} tickLine={false} />
              <YAxis dataKey="label" type="category" width={90} tick={{ fill: chart.tickMuted, fontSize: 12 }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={chart.tooltip} />
              <Bar dataKey="value" fill={chart.accent} radius={[0, 8, 8, 0]} name="Sold" />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <div className="rounded-2xl border border-ink-100 bg-surface p-5 shadow-sm">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h2 className="font-display text-base font-bold text-ink-900">Live Orders</h2>
              <p className="text-xs text-ink-400">Awaiting your action</p>
            </div>
            <Link to="/live-orders" className="text-sm font-semibold text-brand-500 hover:text-brand-600">
              View all
            </Link>
          </div>
          {liveOrders.length === 0 ? (
            <p className="py-8 text-center text-sm text-ink-400">No live orders right now</p>
          ) : (
            <ul className="space-y-3">
              {liveOrders.slice(0, 4).map((o) => (
                <li key={o.id}>
                  <Link
                    to={`/orders/${o.id}`}
                    className="flex items-center gap-3 rounded-xl border border-ink-50 p-3 transition hover:border-brand-200 hover:bg-brand-50/40"
                  >
                    <img src={o.productImage} alt="" className="size-12 rounded-xl object-cover" />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-semibold text-ink-800">
                        {o.productName} × {o.quantity}
                      </p>
                      <p className="truncate text-xs text-ink-400">
                        {o.customerName} · {o.time}
                      </p>
                    </div>
                    <p className="text-sm font-bold text-ink-900">{formatCurrency(o.totalAmount)}</p>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      <div className="mt-6 rounded-2xl border border-ink-100 bg-surface p-5 shadow-sm">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <TrendingUp className="size-4 text-brand-500" />
            <h2 className="font-display text-base font-bold text-ink-900">Recent Customer Orders</h2>
          </div>
          <Link to="/live-orders" className="text-sm font-semibold text-brand-500 hover:text-brand-600">
            View activity
          </Link>
        </div>
        {loading ? (
          <TableSkeleton rows={5} />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[560px] text-left text-sm">
              <thead>
                <tr className="border-b border-ink-100 text-xs font-semibold tracking-wide text-ink-400 uppercase">
                  <th className="pb-3 font-semibold">Product</th>
                  <th className="pb-3 font-semibold">Customer</th>
                  <th className="pb-3 font-semibold">Qty</th>
                  <th className="pb-3 font-semibold">Amount</th>
                  <th className="pb-3 font-semibold">Time</th>
                  <th className="pb-3 font-semibold">Status</th>
                </tr>
              </thead>
              <tbody>
                {recentOrders.map((o) => (
                  <tr key={o.id} className="border-b border-ink-50 last:border-0">
                    <td className="py-3">
                      <Link to={`/orders/${o.id}`} className="font-medium text-ink-800 hover:text-brand-600">
                        {o.productName}
                      </Link>
                    </td>
                    <td className="py-3 text-ink-600">{o.customerName}</td>
                    <td className="py-3 text-ink-600">{o.quantity}</td>
                    <td className="py-3 font-semibold text-ink-800">{formatCurrency(o.totalAmount)}</td>
                    <td className="py-3 text-ink-500">{o.time}</td>
                    <td className="py-3">
                      <StatusBadge status={o.status} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

function ChartCard({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle: string;
  children: React.ReactNode;
}) {
  return (
    <div className="rounded-2xl border border-ink-100 bg-surface p-5 shadow-sm">
      <div className="mb-4">
        <h2 className="font-display text-base font-bold text-ink-900">{title}</h2>
        <p className="text-xs text-ink-400">{subtitle}</p>
      </div>
      {children}
    </div>
  );
}
