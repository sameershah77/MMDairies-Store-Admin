import { useEffect, useRef, useState } from 'react';
import { Bell, LogOut, Menu, Search, Moon, Sun, MapPin, Store, CircleUserRound } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { useSidebar } from '@/context/SidebarContext';
import { useTheme } from '@/context/ThemeContext';
import { useToast } from '@/context/ToastContext';

const notifications = [
  { id: 1, text: 'New live order — Farm Fresh Milk 1L × 2', time: '2 min ago' },
  { id: 2, text: 'Order #O5 is out for delivery', time: '18 min ago' },
  { id: 3, text: 'Customer Ananya Joshi sent a query', time: '1 hr ago' },
];

export function TopNav() {
  const { profile, logout } = useAuth();
  const { setMobileOpen } = useSidebar();
  const { theme, toggleTheme } = useTheme();
  const { toast } = useToast();
  const navigate = useNavigate();

  const [profileOpen, setProfileOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [globalSearch, setGlobalSearch] = useState('');

  const profileRef = useRef<HTMLDivElement>(null);
  const notifRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (profileRef.current && !profileRef.current.contains(e.target as Node)) {
        setProfileOpen(false);
      }
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) {
        setNotifOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!globalSearch.trim()) return;
    navigate(`/customers?q=${encodeURIComponent(globalSearch.trim())}`);
    setGlobalSearch('');
  };

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b border-ink-100 bg-surface/90 px-4 backdrop-blur-md sm:px-6">
      <button
        type="button"
        className="rounded-xl p-2 text-ink-600 hover:bg-ink-100 lg:hidden"
        onClick={() => setMobileOpen(true)}
      >
        <Menu className="size-5" />
      </button>

      <div className="hidden min-w-0 flex-1 items-center gap-3 md:flex">
        <div className="min-w-0">
          <p className="truncate font-display text-sm font-bold text-ink-900 sm:text-base">
            {profile.dairyName}
          </p>
          <div className="mt-0.5 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[11px] text-ink-500">
            <span className="inline-flex items-center gap-1">
              <MapPin className="size-3 text-brand-500" />
              {profile.zoneName}
            </span>
            <span className="text-ink-300">·</span>
            <span className="inline-flex items-center gap-1">
              <Store className="size-3 text-brand-500" />
              {profile.storeName}
            </span>
          </div>
        </div>

        <form onSubmit={handleSearch} className="relative ml-4 hidden max-w-xs flex-1 lg:block xl:max-w-sm">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-ink-400" />
          <input
            value={globalSearch}
            onChange={(e) => setGlobalSearch(e.target.value)}
            placeholder="Search customers, orders..."
            className="h-10 w-full rounded-xl border border-ink-200 bg-ink-50/80 pl-9 pr-3 text-sm outline-none transition focus:border-brand-400 focus:bg-surface focus:ring-3 focus:ring-brand-500/15"
          />
        </form>
      </div>

      <div className="ml-auto flex items-center gap-1.5 sm:gap-2">
        <button
          type="button"
          onClick={toggleTheme}
          className="rounded-xl p-2 text-ink-600 transition hover:bg-ink-100 hover:text-brand-500"
          title={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
          aria-label="Toggle theme"
        >
          {theme === 'dark' ? <Sun className="size-5" /> : <Moon className="size-5" />}
        </button>

        <div className="relative" ref={notifRef}>
          <button
            type="button"
            onClick={() => setNotifOpen((v) => !v)}
            className="relative rounded-xl p-2 text-ink-600 transition hover:bg-ink-100"
          >
            <Bell className="size-5" />
            <span className="absolute top-1.5 right-1.5 size-2 rounded-full bg-danger ring-2 ring-surface" />
          </button>
          {notifOpen && (
            <div className="absolute right-0 mt-2 w-80 overflow-hidden rounded-2xl border border-ink-100 bg-surface shadow-xl shadow-ink-900/10 animate-fade-up">
              <div className="border-b border-ink-100 px-4 py-3">
                <p className="font-display text-sm font-bold text-ink-900">Notifications</p>
              </div>
              <ul className="max-h-72 overflow-y-auto">
                {notifications.map((n) => (
                  <li
                    key={n.id}
                    className="border-b border-ink-50 px-4 py-3 transition hover:bg-ink-50/80"
                  >
                    <p className="text-sm text-ink-700">{n.text}</p>
                    <p className="mt-1 text-xs text-ink-400">{n.time}</p>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>

        <div className="relative" ref={profileRef}>
          <button
            type="button"
            onClick={() => setProfileOpen((v) => !v)}
            className="flex items-center gap-2 rounded-xl py-1 pr-1 pl-1 transition hover:bg-ink-50 sm:pl-2"
          >
            <span className="hidden text-right sm:block">
              <span className="block text-sm font-semibold text-ink-800">{profile.name}</span>
              <span className="block text-[11px] text-ink-400">Store Admin</span>
            </span>
            <img
              src={profile.avatar}
              alt={profile.name}
              className="size-9 rounded-xl bg-brand-50 object-cover ring-2 ring-brand-100"
            />
          </button>

          {profileOpen && (
            <div className="absolute right-0 mt-2 w-56 overflow-hidden rounded-2xl border border-ink-100 bg-surface py-1 shadow-xl shadow-ink-900/10 animate-fade-up">
              <button
                type="button"
                className="flex w-full items-center gap-2.5 px-4 py-2.5 text-sm text-ink-700 hover:bg-ink-50"
                onClick={() => {
                  setProfileOpen(false);
                  navigate('/profile');
                }}
              >
                <CircleUserRound className="size-4 text-ink-400" /> Profile
              </button>
              <div className="my-1 border-t border-ink-100" />
              <button
                type="button"
                className="flex w-full items-center gap-2.5 px-4 py-2.5 text-sm text-danger hover:bg-red-50 dark:hover:bg-red-500/10"
                onClick={async () => {
                  setProfileOpen(false);
                  await logout();
                  toast('Logged out successfully', 'info');
                  navigate('/login');
                }}
              >
                <LogOut className="size-4" /> Logout
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
